 <link href="<?php echo base_url()?>library/pendaftaran/ghpages-materialize.css" type="text/css" rel="stylesheet" media="screen,projection">
  <script src="<?php echo base_url()?>library/pendaftaran/jquery-2.1.4.min.js.download"></script>
  <script src="<?php echo base_url()?>library/pendaftaran/materialize.js.download"></script>
 <link rel="stylesheet" type="text/css" href="<?php echo base_url()?>assets/css/bar.css" />
	<link rel="stylesheet" type="text/css" href="<?php echo base_url()?>assets/css/style.css" />
	<link href="<?php echo base_url()?>library/css/icomoon.css" rel="stylesheet" media="screen">

<nav>
<a id="resp-menu" class="responsive-menu" href="#"><i class="fa fa-reorder"></i> Menu</a>    
   <ul class="menu" style="
   margin-bottom: 0px;>
   <
   li style=;
   padding-left: 10px;
   id=;
   padding-top: 0px;
   "a">
						<img style="float:left;padding-top: 5px;" src="<?php echo base_url()?>assets/img/logo.gif" width="75" ><img style="float:left;padding-top: 3px;" src="<?php echo base_url()?>assets/img/Home_01.png" width="350" >
					</li>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
   <li><a  href="<?php echo base_url() ?>index.php/welcome/index"><i class="icon-home-4"></i> HOME</a>
   </li>
  <li><a href="#"><i class="icon-file-5"></i> PROFIL</a>
  <ul class="sub-menu">
   <li><a href="<?php echo base_url() ?>index.php/welcome/menu_workshop">Workshop</a></li>
   <li><a href="#">Anggota</a>
   <ul>
    <li><a href="<?php echo base_url() ?>index.php/welcome/menu_Dinasti19">Dinasti 19</a></li>
    <li><a href="<?php echo base_url() ?>index.php/welcome/menu_Dinasti20">Dinasti 20</a></li>
    </ul>
   </li>
   <li><a href="<?php echo base_url() ?>index.php/welcome/menu_alumni">Alumni</a></li>
   <li><a href="<?php echo base_url() ?>index.php/welcome/menu_so">SO</a></li>
   </ul>
   </li>
    <li><a  href="http://bit.ly/2cWQolt"><i class="icon-book-3"></i> PENDAFTARAN</a>

  <li><a  href="#"><i class="icon-images"></i> GALLERY</a>
  <ul class="sub-menu">
   <li><a href="<?php echo base_url() ?>index.php/welcome/menu_gproker">Proker</a></li>
   <li><a href="<?php echo base_url() ?>index.php/welcome/menu_gpelatihan">Pelatihan</a></li>
   <li><a href="<?php echo base_url() ?>index.php/welcome/menu_gproyek">Proyek</a></li>
   <li><a href="<?php echo base_url() ?>index.php/welcome/menu_gumum">Umum</a></li>
   </ul>
  </li>
    <li><a  href="<?php echo base_url() ?>index.php/welcome/menu_pelatihan"><i class="icon-busy"></i> PELATIHAN</a>
	
   </li>
  <li><a class="homer" href="<?php echo base_url() ?>index.php/berita/menu_berita"><i class="icon-newspaper"></i> BERITA</a>
  
  </li>
  <li><a  href="<?php echo base_url() ?>index.php/contact/lihat/contact"><i class="icon-location-3"></i> CONTACT</a>
  </li>
  
  
  </ul>
  </nav>  
 
<div class="container">
  <div class="row">

    <div class="col s12 m9 l10">

<div id="input" class="section scrollspy">
       
        <br>
        <div class="row">
          <form class="col s12">
            <div class="row">
              <div class="input-field col s12">
                <input id="nama" type="text" class="validate">
                <label for="nama" class="">NAMA :</label>
              </div>
            </div>
			<div class="row">
              <div class="input-field col s12">
                <input id="prodi" type="text" class="validate">
                <label for="prodi" class="">PRODI :</label>
              </div>
            </div>
			<div class="row">
              <div class="input-field col s12">
                <textarea id="alamat_asal" class="materialize-textarea"></textarea>
                <label for="alamat_asal" class="">ALAMAT ASAL :</label>
              </div>
            </div>
            <div class="row">
              <div class="input-field col s12">
                <textarea id="alamat_sekarang" class="materialize-textarea"></textarea>
                <label for="alamat_sekarang" class="">ALAMAT SEKARANG :</label>
              </div>
            </div>
			<div class="row">
              <div class="input-field col s12">
                <input id="ttl" type="text" class="validate">
                <label for="ttl" class="">TTL :</label>
              </div>
            </div>
			<div class="row">
              <div class="input-field col s12">
                <input id="asal_sekolah" type="text" class="validate">
                <label for="asal_sekolah" class="">ASAL SEKOLAH :</label>
              </div>
            </div>
			<div class="row">
              <div class="input-field col s12">
                <input id="no_hp" type="text" class="validate">
                <label for="no_hp" class="">NO. HP :</label>
              </div>
            </div>
			<div class="row">
              <div class="input-field col s12">
                <input id="hobi" type="text" class="validate">
                <label for="hobi" class="">HOBI :</label>
              </div>
            </div>
			<div class="row">
              <div class="input-field col s12">
                <input id="prestasi" type="text" class="validate">
                <label for="prestasi" class="">PRESTASI (AKADEMIK/NON AKADEMIK) :</label>
              </div>
            </div>
			<div class="row">
              <div class="input-field col s12">
                <input id="alasan" type="text" class="validate">
                <label for="alasan" class="">ALASAN MENGIKUTI WSEC :</label>
              </div>
            </div>
          </form>
        </div>
<br>
 </div>       
</div>
       </div>
      </div>
	  
	  
<div id="footer">
	<center><p style="color:#FFF">Copyright &copy WSEC | 2016 </u></p></center>
	</div>