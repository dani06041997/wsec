<!DOCTYPE html>
<html lang="en">

<head><meta http-equiv="Content-Type" content="text/html; charset=UTF-8">

<meta name="viewport" content="width=device-width, initial-scale=1">
<link rel="stylesheet" type="text/css" href="<?php echo base_url()?>assets/css/bar.css" />
	<link rel="stylesheet" type="text/css" href="<?php echo base_url()?>assets/css/style.css" />
	<link href="<?php echo base_url()?>library/css/icomoon.css" rel="stylesheet" media="screen">
	 <link href="<?php echo base_url()?>library/pendaftaran/ghpages-materialize.css" type="text/css" rel="stylesheet" media="screen,projection">
  <script src="<?php echo base_url()?>library/pendaftaran/jquery-2.1.4.min.js.download"></script>
  <script src="<?php echo base_url()?>library/pendaftaran/materialize.js.download"></script>

 <title>Workshop Electro Polinema</title> 

	<script type="text/javascript">
		/* <![CDATA[ */
		function addLoadEvent(func) {
			var oldonload = window.onload;
			if (typeof window.onload != 'function') {
				window.onload = func;
			} else {
				window.onload = function () {
					oldonload();
					func();
				}
			}
		}
		/* ]]> */
	</script>
			<script type="text/javascript">
			window._wpemojiSettings = {"baseUrl":"https:\/\/s0.wp.com\/wp-content\/mu-plugins\/wpcom-smileys\/twemoji\/2\/72x72\/","ext":".png","svgUrl":"https:\/\/s.w.org\/images\/core\/emoji\/2\/svg\/","svgExt":".svg","source":{"concatemoji":"https:\/\/s1.wp.com\/wp-includes\/js\/wp-emoji-release.min.js?m=1473172720h&ver=4.6.1-RC1-38499"}};
			!function(a,b,c){function d(a){var c,d,e,f,g,h=b.createElement("canvas"),i=h.getContext&&h.getContext("2d"),j=String.fromCharCode;if(!i||!i.fillText)return!1;switch(i.textBaseline="top",i.font="600 32px Arial",a){case"flag":return i.fillText(j(55356,56806,55356,56826),0,0),!(h.toDataURL().length<3e3)&&(i.clearRect(0,0,h.width,h.height),i.fillText(j(55356,57331,65039,8205,55356,57096),0,0),c=h.toDataURL(),i.clearRect(0,0,h.width,h.height),i.fillText(j(55356,57331,55356,57096),0,0),d=h.toDataURL(),c!==d);case"diversity":return i.fillText(j(55356,57221),0,0),e=i.getImageData(16,16,1,1).data,f=e[0]+","+e[1]+","+e[2]+","+e[3],i.fillText(j(55356,57221,55356,57343),0,0),e=i.getImageData(16,16,1,1).data,g=e[0]+","+e[1]+","+e[2]+","+e[3],f!==g;case"simple":return i.fillText(j(55357,56835),0,0),0!==i.getImageData(16,16,1,1).data[0];case"unicode8":return i.fillText(j(55356,57135),0,0),0!==i.getImageData(16,16,1,1).data[0];case"unicode9":return i.fillText(j(55358,56631),0,0),0!==i.getImageData(16,16,1,1).data[0]}return!1}function e(a){var c=b.createElement("script");c.src=a,c.type="text/javascript",b.getElementsByTagName("head")[0].appendChild(c)}var f,g,h,i;for(i=Array("simple","flag","unicode8","diversity","unicode9"),c.supports={everything:!0,everythingExceptFlag:!0},h=0;h<i.length;h++)c.supports[i[h]]=d(i[h]),c.supports.everything=c.supports.everything&&c.supports[i[h]],"flag"!==i[h]&&(c.supports.everythingExceptFlag=c.supports.everythingExceptFlag&&c.supports[i[h]]);c.supports.everythingExceptFlag=c.supports.everythingExceptFlag&&!c.supports.flag,c.DOMReady=!1,c.readyCallback=function(){c.DOMReady=!0},c.supports.everything||(g=function(){c.readyCallback()},b.addEventListener?(b.addEventListener("DOMContentLoaded",g,!1),a.addEventListener("load",g,!1)):(a.attachEvent("onload",g),b.attachEvent("onreadystatechange",function(){"complete"===b.readyState&&c.readyCallback()})),f=c.source||{},f.concatemoji?e(f.concatemoji):f.wpemoji&&f.twemoji&&(e(f.twemoji),e(f.wpemoji)))}(window,document,window._wpemojiSettings);
		</script>
		<style type="text/css">
img.wp-smiley,
img.emoji {
	display: inline !important;
	border: none !important;
	box-shadow: none !important;
	height: 1em !important;
	width: 1em !important;
	margin: 0 .07em !important;
	vertical-align: -0.1em !important;
	background: none !important;
	padding: 0 !important;
}
</style>
<link rel="stylesheet" id="all-css-0" href="<?php echo base_url()?>library/berita/saved_resource" type="text/css" media="all">
<link rel="stylesheet" id="all-css-2" href="<?php echo base_url()?>library/berita/saved_resource(5)" type="text/css" media="all">
<script type="text/javascript">
/* <![CDATA[ */
var LoggedOutFollow = {"invalid_email":"Your subscription did not succeed, please try again with a valid email address."};
/* ]]> */
</script>
<script type="text/javascript" src="<?php echo base_url()?>library/berita/saved_resource(2)"></script><style type="text/css"></style>
<meta name="theme-color" content="#303030">
		<style type="text/css">
			.recentcomments a {
				display: inline !important;
				padding: 0 !important;
				margin: 0 !important;
			}

			table.recentcommentsavatartop img.avatar, table.recentcommentsavatarend img.avatar {
				border: 0px;
				margin: 0;
			}

			table.recentcommentsavatartop a, table.recentcommentsavatarend a {
				border: 0px !important;
				background-color: transparent !important;
			}

			td.recentcommentsavatarend, td.recentcommentsavatartop {
				padding: 0px 0px 1px 0px;
				margin: 0px;
			}

			td.recentcommentstextend {
				border: none !important;
				padding: 0px 0px 2px 10px;
			}

			.rtl td.recentcommentstextend {
				padding: 0px 10px 2px 0px;
			}

			td.recentcommentstexttop {
				border: none;
				padding: 0px 0px 0px 10px;
			}

			.rtl td.recentcommentstexttop {
				padding: 0px 10px 0px 0px;
			}
		</style>
		<nav>
<a id="resp-menu" class="responsive-menu" href="#"><i class="fa fa-reorder"></i> Menu</a>    
   <ul class="menu" style="
   margin-bottom: 0px;>
   <
   li style=;
   padding-left: 20px;
   id=;
   padding-top: 0px;
   "a">
						<img style="float:left;padding-top: 5px;" src="<?php echo base_url()?>assets/img/logo.gif" width="75" ><img style="float:left;padding-top: 3px;" src="<?php echo base_url()?>assets/img/Home_01.png" width="350" >
					</li>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
   <li><a  href="<?php echo base_url() ?>index.php/welcome/index"><i class="icon-home-4"></i> HOME</a>
   </li>
  <li><a href="#"><i class="icon-file-5"></i> PROFIL</a>
  <ul class="sub-menu">
   <li><a href="<?php echo base_url() ?>index.php/welcome/menu_workshop">Workshop</a></li>
   <li><a href="#">Anggota</a>
   <ul>
    <li><a href="<?php echo base_url() ?>index.php/welcome/menu_Dinasti19">Dinasti 19</a></li>
    <li><a href="<?php echo base_url() ?>index.php/welcome/menu_Dinasti20">Dinasti 20</a></li>
    </ul>
   </li>
   <li><a href="<?php echo base_url() ?>index.php/welcome/menu_alumni">Alumni</a></li>
   <li><a href="<?php echo base_url() ?>index.php/welcome/menu_so">SO</a></li>
   </ul>
   </li>
    <li><a  href="http://bit.ly/2cWQolt"><i class="icon-book-3"></i> PENDAFTARAN</a>

  <li><a  href="#"><i class="icon-images"></i> GALLERY</a>
  <ul class="sub-menu">
   <li><a href="<?php echo base_url() ?>index.php/welcome/menu_gproker">Proker</a></li>
   <li><a href="<?php echo base_url() ?>index.php/welcome/menu_gpelatihan">Pelatihan</a></li>
   <li><a href="<?php echo base_url() ?>index.php/welcome/menu_gproyek">Proyek</a></li>
   <li><a href="<?php echo base_url() ?>index.php/welcome/menu_gumum">Umum</a></li>
   </ul>
  </li>
    <li><a  href="<?php echo base_url() ?>index.php/welcome/menu_pelatihan"><i class="icon-busy"></i> PELATIHAN</a>
	
   </li>
  <li><a class="homer" href="<?php echo base_url() ?>index.php/berita/menu_berita"><i class="icon-newspaper"></i> BERITA</a>
  
  </li>
  <li><a  href="<?php echo base_url() ?>index.php/contact/lihat/contact"><i class="icon-location-3"></i> CONTACT</a>
  </li>
  
  
  </ul>
  </nav> 
<style type="text/css" id="syntaxhighlighteranchor"></style>
</head>

<body class="archive category category-redmi-note-2 category-252638423 mp6 customizer-styles-applied color-scheme-red sidebar-closed highlander-enabled highlander-light infinite-scroll neverending infinity-success">
<div id="page" class="hfeed site">
	
	<!-- #masthead -->

	<br>
<div id="sidebar" class="sidebar-area">
	<a id="sidebar-toggle" href="" title="Sidebar"><span class="genericon genericon-close"></span><span class="screen-reader-text">Sidebar</span></a>

			<div id="secondary" class="widget-area" role="complementary">
						<aside id="search-2" class="widget widget_search">
						
	<form role="search" method="get" class="search-form" action="">
	
	
</form>
</aside><aside id="image-4" class="widget widget_image"><div style="overflow:hidden;"><a href="<?php echo base_url(); ?>/assets/img/w_logo.png"><img src="<?php echo base_url(); ?>/assets/img/w_logo.png" class="aligncenter" width="366" height="136"></a></div>
</aside>		
	
<aside id="recent-posts-2" class="widget widget_recent_entries">		<h1 class="widget-title">Recent Posts</h1>		

<ul>
					<li>
				
						</li>
		
	
				</ul>
				
		</aside>

	
		</div><!-- #secondary -->
	<footer id="colophon" class="site-footer" role="contentinfo" style="visibility: visible;opacity: 1;padding-left: 0px;">
				<div id="social-links" class="clear">
			<ul class="social-links clear">
								<li>
					<a href="http://twitter.com/RendyPradhana" class="genericon genericon-twitter" title="Twitter" target="_blank">
						<span class="screen-reader-text">Twitter</span>
					</a>
				</li>
				
				
								<li>
					<a href="https://plus.google.com/112481152099713930166" class="genericon genericon-googleplus" title="Google+" target="_blank">
						<span class="screen-reader-text">Google+</span>
					</a>
				</li>
				
				
								<li>
					<a href="http://rendy37.tumblr.com/" class="genericon genericon-facebook" title="Facebook" target="_blank">
						<span class="screen-reader-text">Tumblr</span>
					</a>
				</li>
							</ul>
		</div><!-- #social-links -->
		
		
	</footer></div><!-- #sidebar -->

	<div id="content" class="site-content">

	<section id="primary" class="content-area">
		<main id="main" class="site-main" role="main" style="
    padding-left: 0px;
">

		
			

						
		
<article id="post-4662" class="post-4662 post type-post status-publish format-standard hentry category-mi4i category-mipad-xiaomi category-redmi-1s category-redmi-2 category-redmi-note category-redmi-note-2 category-redmi-note-4g category-redmi-note-4g-dualsim category-uncategorized category-xiaomi-android tag-1s tag-14407 tag-3g tag-4g tag-7-1 tag-android-2 tag-bagaimana tag-build tag-cara tag-changelog tag-dior tag-donlod tag-download tag-gampang tag-global tag-gucci tag-link tag-mi tag-mi-3 tag-mi-4 tag-mi-note tag-mi2 tag-mi4i-2 tag-mipad tag-miui tag-miui-7-1 tag-note tag-os tag-pc tag-redmi tag-redmi-1s-2 tag-redmi-2-2 tag-redmi-note-3 tag-redmi-note-2-2 tag-rom tag-stabil tag-stable tag-tanpa tag-tips tag-tutorial tag-unduh tag-update tag-upgrade tag-xiaomi">
	
	
	<header class="entry-header" style="
    padding-left: 0px;
">
		<h1 class="entry-title">Form Pendaftaran</h1>
		
					<span class="entry-format-badge genericon genericon-standard"><span class="screen-reader-text">Standard</span></span>
			</header><!-- .entry-header -->

			<div class="container">
  <div class="row">

    <div class="col s12 m9 l10">

<div id="input" class="section scrollspy">
       
        <br>
        <div class="row"><br>
		<center><h4 style="
    padding-left: 70px;
">FORMULIR PENDAFTARAN ANGGOTA BARU WSEC TAHUN 2016/2017</h4></center><br>
          <form class="col s12" style="
    padding-left: 60px;
">
            <div class="row">
              <div class="input-field col s12">
                <input id="nama" type="text" class="validate">
                <label for="nama" class="">NAMA :</label>
              </div>
            </div>
			<div class="row">
              <div class="input-field col s12">
                <input id="prodi" type="text" class="validate">
                <label for="prodi" class="">PRODI :</label>
              </div>
            </div>
			<div class="row">
              <div class="input-field col s12">
                <textarea id="alamat_asal" class="materialize-textarea"></textarea>
                <label for="alamat_asal" class="">ALAMAT ASAL :</label>
              </div>
            </div>
            <div class="row">
              <div class="input-field col s12">
                <textarea id="alamat_sekarang" class="materialize-textarea"></textarea>
                <label for="alamat_sekarang" class="">ALAMAT SEKARANG :</label>
              </div>
            </div>
			<div class="row">
              <div class="input-field col s12">
                <input id="ttl" type="text" class="validate">
                <label for="ttl" class="">TTL :</label>
              </div>
            </div>
			<div class="row">
              <div class="input-field col s12">
                <input id="asal_sekolah" type="text" class="validate">
                <label for="asal_sekolah" class="">ASAL SEKOLAH :</label>
              </div>
            </div>
			<div class="row">
              <div class="input-field col s12">
                <input id="no_hp" type="text" class="validate">
                <label for="no_hp" class="">NO. HP :</label>
              </div>
            </div>
			<div class="row">
              <div class="input-field col s12">
                 <textarea id="hobi" class="materialize-textarea"></textarea>
                <label for="hobi" class="">HOBI :</label>
              </div>
            </div>
			<div class="row">
              <div class="input-field col s12">
                 <textarea id="prestasi" class="materialize-textarea" ></textarea>
                <label for="prestasi" class="">PRESTASI (AKADEMIK/NON AKADEMIK) :</label>
              </div>
            </div>
			<div class="row">
              <div class="input-field col s12">
                 <textarea id="alasan" class="materialize-textarea"></textarea>
                <label for="alasan" class="">ALASAN MENGIKUTI WSEC :</label>
              </div>
            </div>
			
			<div class="file-field input-field">
			  <div class="btn">
				<span>Foto :</span>
				<input type="file" multiple>
			  </div>
			  <div class="file-path-wrapper">
				<input class="file-path validate" type="text" >
			  </div>
			</div>
 
          </form>
        </div>
<br>
 </div>       
</div>
       </div>
      </div>

		
				


			
				

</div></main><!-- #main -->
	</section><!-- #primary -->


	</div><!-- #content -->

	<!-- #colophon -->
</div><!-- #page -->

<div id="footer">
	<center><p style="color:#FFF;margin-top: 16px;">Copyright &copy WSEC | 2016 </u></p></center>
	</div>
		
<script type="text/javascript" src="<?php echo base_url()?>library/berita/saved_resource(3)"></script>
<script type="text/javascript" src="<?php echo base_url()?>library/berita/saved_resource(4)"></script>
<script type="text/javascript">
// <![CDATA[
(function() {
try{
  if ( window.external &&'msIsSiteMode' in window.external) {
    if (window.external.msIsSiteMode()) {
      var jl = document.createElement('script');
      jl.type='text/javascript';
      jl.async=true;
      jl.src='/wp-content/plugins/ie-sitemode/custom-jumplist.php';
      var s = document.getElementsByTagName('script')[0];
      s.parentNode.insertBefore(jl, s);
    }
  }
}catch(e){}
})();
// ]]>
</script>	<script type="text/javascript">
	var skimlinks_pub_id = "725X584219"
	var skimlinks_sitename = "rendy37.wordpress.com";
	</script>
	<script type="text/javascript">
			jQuery.extend( infiniteScroll.settings.scripts, ["jquery","jquery-core","jquery-migrate","mobile-useragent-info","postmessage","jquery_inview","jetpack_resize","loggedout-subscribe","spin","jquery.spin","grofiles-cards","wpgroho","devicepx","jetpack_likes_queuehandler","the-neverending-homepage","writr-navigation","writr-skip-link-focus-fix","underscore","writr-script","swfobject","videopress","jetpack-carousel","twitter-widgets","twitter-widgets-infinity","twitter-widgets-pending","tiled-gallery"] );
			jQuery.extend( infiniteScroll.settings.styles, ["wpcom-smileys","jetpack_likes","loggedout-subscribe","the-neverending-homepage","wpcom-core-compat-playlist-styles","mp6hacks","wpcom-bbpress2-staff-css","genericons","writr-style","writr-color-scheme","writr-wider-style","writr-wpcom","noticons","geo-location-flair","reblogging","a8c-global-print","h4-global","writr-montserrat","jetpack-carousel","tiled-gallery","jetpack-carousel-ie8fix"] );
		</script>		<script>
			var _comscore = _comscore || [];
			_comscore.push({
				c1: "2",
				c2: "7518284"
			});
			(function() {
				var s = document.createElement("script"),
					el = document.getElementsByTagName("script")[0];
				s.async = true;
				s.src = (document.location.protocol == "https:" ? "https://sb" : "http://b") + ".scorecardresearch.com/beacon.js";
				el.parentNode.insertBefore(s, el);
			})();
		</script>
		
<script type="text/javascript">
_tkq = window._tkq || [];
_stq = window._stq || [];
_tkq.push(['storeContext', {'blog_id':'40267462','blog_tz':'7','user_lang':'en','blog_lang':'en','user_id':'0'}]);
_stq.push(['view', {'blog':'40267462','v':'wpcom','tz':'7','user_id':'0','subd':'rendy37'}]);
_stq.push(['extra', {'crypt':'UE40eW5QN0p8M2Y/RE1LVmwrVi5vQS5fVFtfdHBbPyw1VXIrU3hWLHhzVndTdktBX0ddJnpXRjVaOTd6fj1YMX4ydzRUSk0wbVRfODlnNUZzfklVW0haSCxOLitPcGlZM3Y1YjVta0V6eXhUa09kayxPJWU4bmtiS35ncldJMEljSUdwbnUxMC13UllZRkR2TXMyXUxkNFgxS013ZGFkQ1pWdnpTeTh2eUJmP1l1Yi9ZSXMuZ1BkczNMJW13bk44QUVOZEZMenhSLTROMz9uZVJZTGhqUnhBcS89am4uT1BuUyZOQktNNnBjTmpVTzYwVjY2cFZHVGJNX01ybEFFfiw/PXZPVT1qUHFlUVNsUGtaTyxGNitXekdhVmhdei5hPWY='}]);
_stq.push([ 'clickTrackerInit', '40267462', '0' ]);
	</script>

<script>
if ( 'object' === typeof wpcom_mobile_user_agent_info ) {

	wpcom_mobile_user_agent_info.init();
	var mobileStatsQueryString = "";
	
	if( false !== wpcom_mobile_user_agent_info.matchedPlatformName )
		mobileStatsQueryString += "&x_" + 'mobile_platforms' + '=' + wpcom_mobile_user_agent_info.matchedPlatformName;
	
	if( false !== wpcom_mobile_user_agent_info.matchedUserAgentName )
		mobileStatsQueryString += "&x_" + 'mobile_devices' + '=' + wpcom_mobile_user_agent_info.matchedUserAgentName;
	
	if( wpcom_mobile_user_agent_info.isIPad() )
		mobileStatsQueryString += "&x_" + 'ipad_views' + '=' + 'views';

	if( "" != mobileStatsQueryString ) {
		new Image().src = document.location.protocol + '//pixel.wp.com/g.gif?v=wpcom-no-pv' + mobileStatsQueryString + '&baba=' + Math.random();
	}
	
}
</script>

</body></html>